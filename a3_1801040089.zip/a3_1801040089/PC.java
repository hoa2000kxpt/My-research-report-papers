package a3_1801040089;

import utils.AttrRef;
import utils.DOpt;
import utils.DomainConstraint;
import utils.OptType;

/**
 * @overview represents model, year, manufacturer and comps of your personal computer
 * @attributes
 *  model           String
 *  year            Integer         int
 *  manufacturer    String
 *  comps           Set
 * @object a typical PC object is <m,y,r,c> where model(m), year(y), manufacturer(r), comps(c)
 * @abstract_properties
 *  mutable(model) = true /\ optional(model) = false /\ length(model) = 20 /\
 *  mutable(year) = false /\ optional(year) = false /\ min(year) = 1940 /\
 *  mutable(manufacturer) = false /\ optional(manufacturer) = false /\ length(manufacturer) = 20 /\
 *  mutable(comps) = true /\ optional(comps) = false
 *
 * @author DoHoa
 */
public class PC {
    @DomainConstraint(type = "String", mutable = true, optional = false, length = 20)
    private String model;

    @DomainConstraint(type = "Integer", mutable = false, optional = false, min = 1940)
    private int year;

    @DomainConstraint(type = "String", mutable = false, optional = false, length = 20)
    private String manufacturer;

    @DomainConstraint(type = "Set", mutable = true, optional = false)
    private Set comps;

    // Constants
    public static final int LENGTH_MODEL = 20;
    public static final int MIN_YEAR = 1940;
    public static final int LENGTH_MANUFACTURER = 20;

    /**
     * @effects <pre>
     *     if model, year, manufacturer and comps are valid
     *          initialize this as <model, year, manufacturer, comps>
     *      else
     *          initialize this as <> and display errors
     * </pre>
     */
    public PC(@AttrRef("model") String model,
              @AttrRef("year") int year,
              @AttrRef("manufacturer") String manufacturer,
              @AttrRef("comps") Set comps) {
        if (!validateModel (model)) {
            System.err.println ("Invalid PC model: " + model);
            return;
        }

        if (!validateYear (year)) {
            System.err.println ("Invalid PC year: " + year);
            return;
        }

        if (!validateManufacturer (manufacturer)) {
            System.err.println ("Invalid PC manufacturer: " + manufacturer);
            return;
        }

        if (!validateComps (comps)) {
            System.err.println ("Invalid PC components: " + comps);
            return;
        }

        this.model = model;
        this.year = year;
        this.manufacturer = manufacturer;
        this.comps = comps;
    }

    /**
     * @effects return this.model
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("model")
    public String getModel() {
        return this.model;
    }

    /**
     * @effects return this.year
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("year")
    public int getYear() {
        return this.year;
    }

    /**
     * @effects return this.manufacturer
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("manufacturer")
    public String getManufacturer() {
        return this.manufacturer;
    }

    /**
     * @effects return this.comps
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("comps")
    public Set getComps() {
        return this.comps;
    }

    /**
     * @effects <pre>
     *     if model is valid
     *          set this.model = model
     *          return true
     *      else
     *          return false
     * </pre>
     */
    @DOpt(type = OptType.Mutator)
    @AttrRef("model")
    public boolean setModel(String model) {
        if (validateModel (model)) {
            this.model = model;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *     if comps is valid
     *          set this.comps = comps
     *          return true
     *      else
     *          return false
     * </pre>
     */
    @DOpt(type = OptType.Mutator)
    @AttrRef("comps")
    public boolean setComps(Set comps) {
        if (validateComps (comps)) {
            this.comps = comps;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *     if model is valid
     *          return true
     *     else
     *          return false
     * </pre>
     */
    private boolean validateModel(String model) {
        if (model == null || model.isEmpty () || model.length () > LENGTH_MODEL) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @effects <pre>
     *     if year is valid
     *          return true
     *     else
     *          return false
     * </pre>
     */
    private boolean validateYear(int year) {
        if (year < MIN_YEAR) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @effects <pre>
     *     if manufacturer is valid
     *          return true
     *     else
     *          return false
     * </pre>
     */
    private boolean validateManufacturer(String manufacturer) {
        if (manufacturer == null || manufacturer.isEmpty () || manufacturer.length () > LENGTH_MANUFACTURER) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @effects <pre>
     *     if comps is valid
     *          return true
     *     else
     *          return false
     * </pre>
     */
    private boolean validateComps(Set comps) {
        if (comps == null || !comps.repOK ()) {
            return false;
        } else {
            return true;
        }
    }

    @Override
    public String toString() {
        return ("PC:<" + model + ", " + year + ", " +
                manufacturer + ", " + comps.toString () + ">.");
    }

    /**
     * @effects <pre>
     *     if this satisfies abstract properties
     *          return true
     *     else
     *          return false
     * </pre>
     */
    public boolean repOk() {
        return (validateModel (model) && validateYear (year)
                && validateManufacturer (manufacturer) && validateComps (comps));
    }
}
