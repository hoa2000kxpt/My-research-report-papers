package a3_1801040089;

/**
 * @overview  show the PC Report
 */
public class PCReport {

    /**
     * @effects
     *  a tabular report about PC objects is returned and generated in this
     */
    public String displayReport(PC[] objects) {
        int col1 = 3, col2 = PC.LENGTH_MODEL, col3 = 6,
                col4 = PC.LENGTH_MANUFACTURER, col5 = 50;
        String str = "";
        int count = 1;
        str += "---------------------------------------------------------------------------------------------------\n";
        str += "                                           PCPROG REPORT\n";
        str += "---------------------------------------------------------------------------------------------------\n";
        for (PC pc : objects) {
            str += String.format("%" + col1 + "s", count + " ");
            str += String.format("%" + col2 + "s", pc.getModel() + " ");
            str += String.format("%" + col3 + "s", pc.getYear() + " ");
            str += String.format("%" + col4 + "s", pc.getManufacturer() + " ");
            str += String.format("%" + col5 + "s%n", pc.getComps().toArrayString ());
            count++;
        }
        str += "---------------------------------------------------------------------------------------------------\n";
        return str;
    }

}