package a3_1801040089;

import utils.*;
import utils.collections.Collection;
import java.util.Vector;

/**
 * @overview Set are mutable and unrestrained data structure
 * @attributes
 *  objects     Set<Object>     Vector<Object>
 * @object A typical Set object is c={x1,...,xn}, where x1,...,xn are
 * elements.
 * @abstract_properties
 * mutable(objects) = true /\ option(objects) = false /\
 * for all x in objects. x is Object /\
 * for all x, y in objects. x != y
 */
public class Set implements Collection<Object> {
    @DomainConstraint(type = "Vector", mutable = true, optional = false)
    private Vector<Object> objects;

    /**
     * @effects <pre>
     *      create an empty Set<>
     * </pre>
     */
    public Set() {
        objects = new Vector<> ();
    }

    /**
     * @modifies <tt>this</tt>
     * @effects <pre>
     *   if x is already in this
     *     do nothing
     *   else
     *     add x to this, i.e., this_post = this + {x}</pre>
     */
    @DOpt(type = OptType.MutatorAdd)
    public void add(Object x) {
        if (getIndex (x) < 0) {
            objects.add (x);
        }
    }

    /**
     * @modifies <tt>this</tt>
     * @effects <pre>
     *   if x is not in this
     *     do nothing
     *   else
     *     remove x from this, i.e.
     *     this_post = this - {x}</pre>
     */
    @DOpt(type = OptType.MutatorRemove)
    public void remove(Object x) {
        int i = getIndex (x);
        if (i < 0)
            return;
        objects.set (i, objects.lastElement ());
        objects.remove (objects.size () - 1);
    }

    /**
     * @effects <pre>
     *  if x is in this
     *    return true
     *  else
     *    return false
     * </pre>
     */
    @DOpt(type = OptType.ObserverContains)
    public boolean isIn(Object x) {
        return (getIndex (x) >= 0);
    }

    /**
     * @effects <pre>
     *     return the number of elements in the Set
     * </pre>
     */
    @DOpt(type = OptType.ObserverSize)
    public int size() {
        return objects.size ();
    }

    /**
     * @effects if this is not empty
     * return array String[] of elements of this
     * else
     * return null
     */
    @DOpt(type = OptType.Observer)
    public Object[] getObjects() {
        if (size () == 0)
            return null;
        else
            return objects.toArray (new Object[size ()]);
    }

    /**
     * @effects <pre>
     *  Return the elements in Vector objects
     *  </pre>
     */
    @DOpt(type = OptType.Observer)
    public Object getElement(int index) {
        return objects.get(index);
    }

    /**
     * @effects <pre>
     *  if this is empty
     *    throw an IllegalStateException
     *  else
     *    return an arbitrary element of this</pre>
     */
    public Object choose() throws IllegalStateException {
        if (size () == 0)
            throw new IllegalStateException ("Set.choose: set is empty");
        Vector<Object> clone = (Vector<Object>) objects.clone ();
        return clone.lastElement ();
    }

    /**
     * @effects <pre>
     *  if x is in this
     *    return the index where x appears
     *  else
     *    return -1
     * </pre>
     */
    private int getIndex(Object x) {
        for (int i = 0; i < objects.size (); i++) {
            if (x.equals (objects.get (i))) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public String toString() {
        if (size () == 0) {
            return "Your set of components:{ }";
        }

        String s = "Set:{" + objects.elementAt (0).toString ();
        for (int i = 1; i < size (); i++) {
            s = s + ", " + objects.elementAt (i).toString ();
        }
        return s + "}";
    }

    public String toArrayString() {
        if (size () == 0) {
            return "Your set of components:[ ]";
        }

        String s = "[" + objects.elementAt (0).toString ();
        for (int i = 1; i < size (); i++) {
            s = s + ", " + objects.elementAt (i).toString ();
        }
        return s + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Set)) {
            return false;
        }

        if (o.getClass () != this.getClass ()) {
            return false;
        }

        Set h = (Set) o;
        return h.objects.equals (o);
    }

    /**
     * @effects <pre>
     *   if this satisfies abstract properties
     *     return true
     *   else
     *     return false
     * </pre>
     */
    public boolean repOK() {
        if (objects == null)
            return false;

        for (int i = 0; i < objects.size (); i++) {
            Object x = objects.get (i);

            for (int j = i + 1; j < objects.size (); j++) {
                if (objects.get (j).equals (x))
                    return false;
            }
        }
        return true;
    }

    /**
     * @effects
     *      Return a clone of the object obj
     */
    @Override
    public Set clone() {
        Set obj = new Set();
        if(this.size()!=0) {
            for(Object i : this.objects) {
                obj.add (i);
            }
        }
        return obj;
    }
}